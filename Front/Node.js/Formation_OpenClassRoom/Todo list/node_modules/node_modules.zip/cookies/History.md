0.5.0 / 2014-07-27
==================

  * Integrate with `req.protocol` for secure cookies
  * Support `maxAge` as well as `maxage`

0.4.1 / 2014-05-07
==================

  * Update package for repo move

0.4.0 / 2014-01-31
==================

  * Allow passing an array of strings as keys

0.3.8-0.2.0
===========

  * TODO: write down history for these releases

0.1.6 / 2011-03-01
==================

  * SSL cookies secure by default
  * Use httpOnly by default unless explicitly false

0.1.5 / 2011-02-26
==================

  * Delete sig cookie if signed cookie is deleted

0.1.4 / 2011-02-26
==================

  * Always set path

0.1.3 / 2011-02-26
==================

  * Add sensible defaults for path

0.1.2 / 2011-02-26
==================

  * Inherit cookie properties to signature cookie

0.1.1 / 2011-02-25
==================

  * Readme updates

0.1.0 / 2011-02-25
==================

  * Initial release
